<?php
    session_start();
    require 'check_if_added.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>iMobile Service</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
            <div class="container">
                <div class="jumbotron">
                    <h1>Välkommen!</h1>
                    <p>Vi lagar alla typer av mobiler, datorer, surfplattor och skrivare.</p>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <img src="img/bilny.jpg" height="400px" width="400% />
                        <div class="thumbnail">
                            <a href="cart.php">
                                
                            </a>
                            <center>
                                <div class="caption">
                                   
                                </div>
                            </center>
                        </div>
                    </div>
                   
                </div>
            </div>
            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               <center>
                   <p>Copyright 2022 &copy iMobile Service. All Rights Reserved. | Contact Us: +46 720-010242</p>
                   <p>Email:info@imobile.se  | Adress: Sancta birgittagatan7, 702 14 , Örebro</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>

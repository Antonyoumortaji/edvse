/* phpMyAdmin configuration snippet */

/* Paste it to your config.inc.php */

$cfg['lang'] = 'sv';
$cfg['Console']['Mode'] = 'collapse';

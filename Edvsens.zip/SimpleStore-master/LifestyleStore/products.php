<?php
    session_start();
    require 'check_if_added.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>iMobile Service</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
            <div class="container">
                <div class="jumbotron">
                    <h1>Välkommen!</h1>
                    <p>Vi lagar alla typer av mobiler, datorer, surfplattor och skrivare.</p>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s21s.jpg" alt="Cannon">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy A21s</h3>
                                  <p> Skärm: 1150:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s20u.jpg" alt="Sony DSLR">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S20 Ultra</h3>
                                    <p> Skärm: 3450:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                    
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s20p.jpg" alt="Sony DSLR">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S20+</h3>
                                    <p> Skärm: 3650:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            <a href="cart.php">
                                <img src="img/s200.jpg" alt="Olympus">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S20</h3>
                                    <p> Skärm: 3250:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                   
                                </div>
                            </center>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s10p.jpg" alt="Titan 301">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S10 plus</h3>
                                    <p> Skärm: 3650:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                  
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s10.jpg" alt="Titan 201">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S10</h3>
                                    <p> Skärm: 3650:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                    
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s88.JPG" alt="htm milan">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy S8 </h3>
                                    <p> Skärm: 2250:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                    
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/s8p.jpg" alt="Favre Leuba">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>S8 plus</h3>
                                     <p> Skärm: 2750:-  Batteri: 675:-  Baksida: 650:-  </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                   
                                </div>
                            </center>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/a7.jpg" alt="Raymond shirt">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy A7</h3>
                                     <p> Skärm: 1050:-  Batteri: 575:-   </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                   
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/a9.jpg" alt="Charles shirt">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy A9</h3>
                                   <p> Skärm: 1450:-  Batteri: 575:-   </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/a10.jpg" alt="HXR">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy A10</h3>
                                     <p> Skärm: 1050:-  Batteri: 675:-    </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                            </center>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="thumbnail">
                            
                                <img src="img/a71.jpg" alt="PINK">
                            </a>
                            <center>
                                <div class="caption">
                                    <h3>Galaxy A71</h3>
                                     <p> Skärm: 1550:-  Batteri: 575:-    </p>
                                        <p >Övriga fel: Kontakta oss</p>
                                  
                                </div>
                            </center>
                        </div>
                    </div>
                </div>
            </div>
            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               <center>
                   <p>Copyright 2022 &copy iMobile Service. All Rights Reserved. | Contact Us: +46 720-010242</p>
                   <p>Email:info@imobile.se  | Adress: Sancta birgittagatan7, 702 14 , Örebro</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>

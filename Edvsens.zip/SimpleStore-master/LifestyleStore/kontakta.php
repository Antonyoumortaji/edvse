
<?php
// 301 Moved Permanently

header("Location: https://www.instagram.com/imobileservice_/", true, 301);
exit();
?>
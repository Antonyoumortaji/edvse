<?php
    session_start();
    require 'check_if_added.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>iMobile Service</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
            <div class="container">
                <div class="jumbotron">
                    <center>
                    <h1>Välj din mobil</h1>
                    <p> Hos oss, det är alltid kostnadsfritt att felsöka din enhet!</p>

                    </center>
                </div>
            </div>
            
                            <center>
                                <div class="container">
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           
                                <img src="img/i7.jpg" alt="mobil" height="100px" width="70%">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize">iPhone 7 / 7plus</p>
                                        <p> Skärm: 699:-  Batteri: 380:-  Laddkontakt: 400:-  Kamera: 500:-</p>
                                        <p >Baksida/ljudfel: Kontakta oss</p>
                                        
                                </div>
                           </center>
                       </div>
                   </div>

           <div class="container">
            <div>
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           
                                <img src="img/i8.jpg" height="100px" width="70%" alt="Camera">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize">iPhone 8</p>
                                        <p> Skärm: 790:-  Batteri: 480:-  Laddkontakt: 400:-  Kamera: 500:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                        
                               
                           </center>
                       
                   </div> 
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/i8p.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 8 plus</p>
                                     <p> Skärm: 850:-  Batteri: 490:-  Laddkontakt: 550:-  Kamera: 500:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/ixsm.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone XS Max</p>
                                     <p> Skärm: 1400:-  Batteri: 650:-  Laddkontakt: 650:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/ix.jpg" height="100px" width="24%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone XS </p>
                                     <p> Skärm: 1100:-  Batteri: 550:-  Laddkontakt: 650:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/ixx.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone X</p>
                                     <p> Skärm: 1100:-  Batteri: 550:-  Laddkontakt: 650:-  Kamera: 600:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/ixr.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone XR</p>
                                     <p> Skärm: 1100:-  Batteri: 550:-  Laddkontakt: 650:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/i11.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 11</p>
                                     <p> Skärm: 1350:-  Batteri: 650:-  Laddkontakt: 650:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/i11pro.jpg" height="100px" width="70%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 11 Pro</p>
                                     <p> Skärm: 1450:-  Batteri: 850:-  Laddkontakt: 850:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/i11pm.jpg" height="100px" width="68%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 11 Pro Max</p>
                                     <p> Skärm: 1850:-  Batteri: 850:-  Laddkontakt: 850:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           
                               <img src="img/i12.jpg" height="100px" width="85%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 12(mini/pro)</p>
                                     <p> Skärm: 2250:-  Batteri: 850:-  Laddkontakt: 850:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                          
                               <img src="img/i12pm.jpg" height="100px" width="85%" alt="Watch">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">iPhone 12 Pro Max</p>
                                     <p> Skärm: 2950:-  Batteri: 850:-  Laddkontakt: 850:-  Kamera: 950:-</p>
                                        <p >Övriga fel: Kontakta oss</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   
                           <center>
                             
                   </div>

            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               <center>
                   <p>Copyright 2022 &copy iMobile Service. All Rights Reserved. | Contact Us: +46 720-010242</p>
                   <p>Email:info@imobile.se  | Adress: Sancta birgittagatan7, 702 14 , Örebro</p>
                   
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>

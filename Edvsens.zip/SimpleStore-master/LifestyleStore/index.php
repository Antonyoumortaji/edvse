<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        
        <title>iMobile Service</title>
        <meta charset="UTF-8">
        <title>iMobile Service</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <title>iMobile Service</title>
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <title>iMobile Service</title>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>

           <?php
            require 'header.php';
           ?>
           <style>
          body{
               background-image:url("img/white.jpg");
          }
     </style>
     <img src="img/butik.jpg" width="2850" height="750" />
     <div  class="thumbnail"></div>
    
                                <div class="container">
               <div class="row">
               
           </div>
           <center>

           <div class="container">
            <center>
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="mobileservice.php">
                                <img src="img/mobil.jpg" alt="mobil" height="300px" width="50%">
                           </a>

                           <center>
                                <div class="caption">
                                        <p id="autoResize">Mobil Service</p>
                                        <p>Här hittar du alla tjänster som vi erbjuder för din mobil.</p>
                                </div>
                           </center>
                       </div>
                   </div>


           <div class="container">
            <div>
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="mob.php">
                                <img src="img/dator.jpg" height="300px" width="50%" >
                           </a>

                           <center>

                                <div class="caption">
                                        <p id="autoResize">Dator Service</p>
                                        <p>Här hittar du alla tjänster som vi erbjuder för din dator.</p>
                                </div>
                           </center>

                       </div>

                   </div> 
                   <div class="container">
            <div>
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="tv.php">
                                <img src="img/tv.jpg" height="300px" width="80%" >
                           </a>

                           <center>

                                <div class="caption">
                                        <p id="autoResize">TV Reparation</p>
                                        <p>vi reparerar alla typer av Tv.</p>
                                </div>
                           </center>

                       </div>

                   </div> 

                   
                   <div class="container">
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="surfplatta.php">
                               <img src="img/ipad.jpg" height="300px" width="68%" >
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">Surfplatta</p>
                                    <p>Laga din surfplatta.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                    <div class="container">
            <div>
               <div class="row">


                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="skrivaree.php">
                               <img src="img/printer.jpg" height="300px" width="60%" >
                           </a>
                           <center>
                               <div class="caption">
                                   <p id="autoResize">Skrivare</p>
                                   <p>Laga alla typer av skrivare och erbjuder även andra tjänster.</p>
                               </div>
                                    
                           </center>

                       </div>

                   </div> 
                   <div class="container">
            <div>
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="batteri.php">
                                <img src="img/biln.jpg" height="300px" width="37%" >
                           </a>

                           <center>

                                <div class="caption">
                                        <p id="autoResize">Batterier</p>
                                        <p>Vi bytter batterier för bilnycklar och klockor.</p>
                                </div>
                           </center>

                       </div>
                   </div>
               </div>
           </center>
           </div>
       </center>
            <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright 2022 &copy iMobile Service. All Rights Reserved. | Contact Us: +46 720-010242</p>
                   <p>Email:info@imobile.se  | Adress: Sancta birgittagatan7, 702 14 , Örebro</p>
                   <p></p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
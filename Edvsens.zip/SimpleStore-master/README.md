# Simple-Store

![preview](preview/preview.gif)

An Online Shopping website
[http://simplestore0528.herokuapp.com](http://simplestore0528.herokuapp.com)

## Features

* All forms validated on Client side using HTML5 and on Server side using PHP.
* Responsive and nice looking webpages

## Running the project

* Install WAMP or XAMP
* Import database from store.sql file.
* Run WAMP and open web page from browser: [http://localhost/SimpleStore/index.php](http://localhost/SimpleStore/index.php)
